"""
Project Name: MelodyBrenden_FinalProject.py
Author: Brenden Melody
Date last updated: 12 Oct 2024
Description: Program is designed to play a version of Tic-Tac-Toe that allows players
            to choose their names.
"""

import tkinter as tk
from tkinter import messagebox

# Global variables
# board is initialized in order to provide the initial look of the board with blanks
board = [['', '', ''], ['', '', ''], ['', '', '']]
# initializes the initial names for Player 1 and Player 2
player1 = "Player 1"
player2 = "Player 2"
# sets the current player as X and changes depending on whose turn it is
current_Marker = 'X'
# initializes the Winners name
winner = "Player"
# initializes buttons array
buttons = []
# initializes number of moves performed
moves = 0


# move module handles all the text for the buttons and allowing players to choose
# which buttons will be claimed by which player
def move(row, col):
    global current_Marker, winner, moves

    if board[row][col] == '':           # detecting if button is blank
        board[row][col] = current_Marker    # setting area to be claimed by the player
        buttons[row][col]['text'] = current_Marker      # setting the text for the button
        moves += 1

        if current_Marker == 'X':       # this runs every time and is just in case
            winner = player1            # one of the players has just won and makes sure their name appears
        elif current_Marker == 'O':
            winner = player2

        if check_winner(current_Marker):        # this actully checks if someone has won, or detects if it is a draw
            tk.messagebox.showinfo('Game Over', f'{winner} wins!')
            reset_game()
        elif moves == 9:
            tk.messagebox.showinfo('Game Over', 'It\'s a draw!')
            reset_game()
        else:
            current_Marker = 'O' if current_Marker == 'X' else 'X'      # this decides player turns if there wasn't a winner or a draw on the last turn

"""
The check_winner module determines if the player has won the game by checking the board for three Xs or Os in a row
"""
def check_winner(player):
    # This checks every row to see if there are any possible wins
    for i in range(3):
        if board[i][0] == board[i][1] == board[i][2] == player:
            return True

    # This checks columns for any possible wins
    for j in range(3):
        if board[0][j] == board[1][j] == board[2][j] == player:
            return True

    # This checks the two diagonals for any wins
    if board[0][0] == board[1][1] == board[2][2] == player:
        return True
    if board[0][2] == board[1][1] == board[2][0] == player:
        return True

    return False

"""
This resets the game after every win. I couldn't get a button to work properly in a way that was good
so I had it update automatically since it made the most sense to me
"""
def reset_game():
    global board, current_Marker, moves # initializing all globals
    board = [['', '', ''], ['', '', ''], ['', '', '']]  #recalling how the board works
    current_player = 'X'        # resetting the current player to default
    moves = 0

    for row in buttons: # reinitializing the buttons on the board
        for button in row:
            button['text'] = ''

"""
This function actually initializes the game once the Play Game button has been pressed
including the Title changing depending on which names the players have chosen
"""
def game():
    global player1, player2 # initializing the global player names
    firstPlayer = player1   # setting the player names to local variables
    secondPlayer = player2
    game = tk.Tk()
    title = (firstPlayer, ' Vs. ', secondPlayer)    # the changeable title
    game.title(title)   
    global buttons  # initializing the buttons
    buttons = []

    for i in range(3):  # automatically initializing all buttons in 3 by 3 grid
        row = []
        for j in range(3):
            button = tk.Button(game, text='', width=10, height=5, command=lambda x=i, y=j: move(x, y))
            button.grid(row=i, column=j)
            row.append(button)
        buttons.append(row)

    game.mainloop()

"""
This module actually initializes the main menu with the 3 main buttons to start the game
change the name of the players, and to close the game.
"""
def main():
    mainMenu = tk.Tk()
    mainMenu.title("Tic-Tac-Toe")
    welcomeMessage = tk.Label(mainMenu, text="Welcome to Tic-Tac-Toe!")
    multiButton = tk.Button(mainMenu, text="Play Game", command=lambda: game())
    registryButton = tk.Button(mainMenu, text="Register Players", command=lambda: registerPlayers())
    exitButton = tk.Button(mainMenu, text="Exit", command=mainMenu.quit)

    welcomeMessage.pack()
    multiButton.pack()
    registryButton.pack()
    exitButton.pack()
    mainMenu.mainloop()

"""
The strangest part of this game to make, couldn't get it to work until I made it its own class.
This handles the names for the players allowing users to enter the Players names so that it works with
the later functions for telling them they won
"""
class registerPlayers(tk.Tk):
    def __init__(self):
        super().__init__()
        print("registerPlayers was called") # diagnostic print statement
        self.title("Register Players")
        # The actual labels, buttons, and entry boxes
        registerMessage = tk.Label(self, text='Please enter player names: ')
        player1Label = tk.Label(self, text='Player 1: ')
        self.player1Entry = tk.Entry(self, textvariable='player1')
        player2Label = tk.Label(self, text='Player 2: ')
        self.player2Entry = tk.Entry(self, textvariable='player2')
        confirmButton = tk.Button(self, text='Confirm', command=lambda: self.confirmPlayers())
        registerMessage.pack()
        player1Label.pack()
        self.player1Entry.pack()
        player2Label.pack()
        self.player2Entry.pack()
        confirmButton.pack()

    """
This function connects to the confirm button in the init function and updates the names of
the players from their defaults
    """
    def confirmPlayers(self):
        print("confirmPlayers was called")
        global player1
        global player2
        player1 = self.player1Entry.get()
        player2 = self.player2Entry.get()
        print(player1, player2)
        self.destroy()


if __name__ == '__main__':
    main()
